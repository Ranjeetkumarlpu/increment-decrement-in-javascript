<!DOCTYPE html>
<html>
<head>
<style>
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
a:link, a:visited {
  background-color: #45a049;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color: lightseagreen;
}
</style>
</head>
<body>

<h2>Welcome to Blog Pages</h2>
<!--<p>Resize the browser window to see the effect. When the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other.</p>-->
<?php
    $connection=mysqli_connect('localhost','root','','bidtheory');
    if(isset($_POST['send'])){
        $title=$_POST['title'];
        $description=$_POST['description'];
        $fileToUpload=$_POST['fileToUpload'];
        $Category=$_POST['Category'];
        $messages=$_POST['messages'];
        
        $request="INSERT INTO `blogs` (`title`, `description`, `fileToUpload`, `Category`, `messages`) VALUES ('$title', '$description', '$fileToUpload', '$Category', '$messages')";
        mysqli_query($connection,$request);
        echo '<script>alert("Thank You")</script>';
    }
    
    ?>
<div class="container">
  <form action="blogs.php" method="post">
  <div class="row">
    <div class="col-25">
      <label for="fname">Title</label>
    </div>
    <div class="col-75">
      <input type="text" id="title" name="title" placeholder="" required>
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="lname">Description</label>
    </div>
    <div class="col-75">
      <input type="text" id="description" name="description" placeholder="" style="height:70px" required>
    </div>
  </div><br>
  Select image to upload:
  <input type="file" name="fileToUpload" id="fileToUpload">
  
  <div class="row">
    <div class="col-25">
      <label for="country">Category</label>
    </div>
    <div class="col-75">
      <select id="country" name="Category">
        <option value="Business">Business</option>
        <option value="Education">Education</option>
        <option value="News">News</option>
      </select>
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="subject">Messages</label>
    </div>
    <div class="col-75">
      <textarea id="subject" name="messages" placeholder="Write something.." style="height:200px"></textarea>
    </div>
  </div>
  <br>
  <div class="row">
    <a href="index.php" target="">Home</a>
    <input type="submit" name="send" value="Submit">
  </div>
  </form>
</div>

</body>
</html>


