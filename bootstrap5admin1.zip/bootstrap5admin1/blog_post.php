<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Blog Post</title>
	<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>
<?php
//include("blogs_post.php");
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bidtheory";

// Create connection
$connection=new mysqli('localhost','root','','bidtheory');
// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$mysql = "SELECT id, title, description, fileToUpload , Category, messages  FROM blogs";
$result = $connection->query($mysql);

if ($result->num_rows > 0) {
    echo "<table><tr>
    <th>Id</th>
    <th>Title</th>
    <th>Description</th>
    <th>Image/Video</th>
    <th>Category</th>
    <th>Message</th>
    </tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>
        <td>" . $row["id"]. " </td>
        <td>" . $row["title"]. " </td>
         <td>" . $row["description"]. " </td>
          <td>" . $row["fileToUpload"]. " </td>
           <td>" . $row["Category"]. " </td>
           <td>" . $row["messages"]. " </td>
        </tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

//$conn->close();
?>
</body>
</html>